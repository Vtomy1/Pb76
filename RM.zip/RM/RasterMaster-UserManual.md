# Raster Master User Manual

## What Raster Master Does

Raster Master is an all-in-one graphics workstation for retro and modern game development: a sprite/icon editor, tile map editor, animation editor, and sound effect generator in one project, with code generation for 20+ compilers and interpreters — including FreePascal, Turbo Pascal, C, QuickBASIC/QB64, GW-BASIC, and several Amiga targets.

Everything you build — sprites, maps, animations, sound — lives in one project file and can be exported as ready-to-compile source code, or as compact binary asset files for `BlockRead`/`BLOAD`-style loading.

---

## Sprite & Icon Editor

The core pixel editor. Draw and manage sprites and icons with support for:

- **2-color**, **4-color (CGA)**, **16-color (EGA/VGA)**, and full **256-color** palettes
- A filmstrip/thumbnail view (128×128 icons) for managing many images in one project
- Import from PNG, BMP, JPG, GIF, PCX, and IFF/ILBM
- Direct clipboard paste, for a fast round-trip with other editors
- Right-click any thumbnail for **Properties** (Name, ID, Tag) — the same metadata scheme used across the map and animation editors, so a sprite keeps its identity everywhere it's used

## Sprite Sheet Import

Import an existing sheet from PNG, BMP, or JPG and split it into individual sprites by grid cell, rather than hand-cropping each frame. If you built your sheet in **Sprite RePacker**, you can instead pull it in with full per-sprite crop data already attached (see *Working with the Companion Tools* below).

## Tile Map Editor

A full 2D tile-based level editor that uses your sprite images as tiles:

- Paint tiles onto a grid-based map canvas
- Tile ImageList thumbnails stay in sync with your sprite images, including transparency — each tile lists its transparent color the same way a sprite does
- **Hitboxes** — attach one or more collision rectangles to a tile or map entry, independent of the tile's visual bounds. Useful for platformers and top-down games where the collidable area doesn't match the full sprite frame (e.g. a taller character sprite with a smaller feet-level hitbox).
- Map data exports alongside your sprite data using the same compiler-target list as the sprite editor (21 targets across BASIC, Pascal, C, and JavaScript families), so map and graphics code always match the language you're compiling for.

## Sprite Animation

Sequence sprites from your project into a named animation:

- Add frames in order, reorder them, and set per-frame duration
- **Play/Stop** controls with an **FPS gauge** for previewing timing before you export
- Export animation frame order and timing alongside the sprite data itself, ready to drive a game loop in your target language

## Sound Effects

An integrated **sfxr-style** sound effect generator, built into the same editor as your graphics assets — no separate tool needed for jumps, hits, pickups, explosions, and other short retro SFX.

## Palette Tools

- Palette editor covering 2/4/16/256-color modes, with direct EGA/VGA DAC-style editing
- **Master Palette Builder** — scans every image in the project and builds one shared palette via combined-histogram Median Cut, so a whole project's sprites and tiles can share a single, consistent palette instead of one per image
- Open/save/copy/paste palette operations, with content-based auto-detection when opening `.pal` files (JASC magic bytes, VGA 6-bit range checks, file-size validation), so you don't have to tell it which palette format you're loading

## Project Files

Save every image, map, animation, and palette into one project file. This keeps a whole game's graphics assets — sprites, tiles, animations, sound effects — portable as a single file you can move between machines or hand to a collaborator, instead of juggling loose images and data files.

---

## Code Generation

This is where Raster Master earns its name: instead of handing you a PNG and leaving the rest to you, it generates **embedded source code arrays** ready to paste directly into your project.

### Compiler Targets

21 targets across four families:

| Family | Targets |
|---|---|
| Pascal | Turbo Pascal, Quick Pascal, **FreePascal**, TMT Pascal, HiSoft Pascal (Amiga), FreePascal 68k (Amiga) |
| C | Turbo C, Quick C, Open Watcom, GCC, vbcc (Amiga) |
| BASIC | QuickBASIC/QB64, FreeBASIC, GW-BASIC/PC-BASIC, Turbo/Power Basic, BAM Basic, AmigaBASIC |
| JavaScript | raylib/emscripten web target |

### Export Formats

- **Source code** — per-image or per-map embedded arrays in your chosen language
- **RES text** — a combined, human-readable resource file bundling every asset's generated source into one include file
- **RES binary / XGF** — a packed binary format: header plus packed pixel data, byte-identical to what the DATA/const arrays contain, for loading assets without embedding them as literal source
- **Transparent mask** — a second AND-mask export alongside the image, for masked sprite blitting

### FreePascal Example — Generated Sprite Unit

A typical FreePascal export for a 16-color sprite looks like this:

```pascal
unit uSprite01;

interface

const
  Sprite01_Width  = 16;
  Sprite01_Height = 16;
  Sprite01_Pal: array[0..15] of record R, G, B: Byte; end = (
    (R:0;   G:0;   B:0),
    (R:255; G:0;   B:0),
    (R:0;   G:255; B:0)
    // ... remaining palette entries
  );
  Sprite01_Data: array[0..127] of Byte = (
    $00, $11, $22, $33, $44, $55, $66, $77
    // ... packed pixel data
  );

implementation

end.
```

Apply the palette with `SetRGBPalette` (FreePascal uses 8-bit 0–255 values, unlike Turbo Pascal's 6-bit 0–63):

```pascal
uses Graph;

var
  I: Integer;
begin
  for I := 0 to 15 do
    SetRGBPalette(I, Sprite01_Pal[I].R, Sprite01_Pal[I].G, Sprite01_Pal[I].B);
end;
```

### FreePascal Example — Loading a Packed Binary (XGF) Asset

If you exported **RES binary/XGF** instead of embedded source, load it at runtime with a stream instead of compiling the pixel data into your executable:

```pascal
var
  F: TFileStream;
  Header: array[0..6] of Byte;
  PixelData: array of Byte;
  DataLen: Word;
begin
  F := TFileStream.Create('sprite01.xgf', fmOpenRead);
  try
    F.ReadBuffer(Header, SizeOf(Header));      // target-specific header
    DataLen := Header[5] or (Header[6] shl 8); // length field
    SetLength(PixelData, DataLen);
    F.ReadBuffer(PixelData[0], DataLen);
  finally
    F.Free;
  end;
  // PixelData now holds the packed pixels, ready to blit
end;
```

This keeps your compiled executable small and your assets swappable without a rebuild — useful once a project has more than a handful of sprites.

---

## Transparency

Sprites, tiles, and animation frames all share the same transparency model: a designated transparent color plus a transparent-mode flag, carried consistently from the sprite editor through to the map and animation editors. When you export a **Transparent Mask**, Raster Master generates the matching AND-mask data so masked blits in your target language work without extra setup on your end.

---

## Amiga Support

Raster Master exports AmigaBASIC **Bobs**, **VSprites**, and `PUT`-format graphics natively, alongside HiSoft Pascal, FreePascal 68k, and vbcc code generation — so the same project that targets a modern raylib build can also target real 68k Amiga hardware.

## Web & Modern Targets

Pair Raster Master's raylib/JavaScript export with emscripten to build cross-platform games for Windows, Linux, and macOS, or fully playable browser games you can publish directly on itch.io — from the same source assets you built for DOS-era targets.

---

## Working with the Companion Tools

Raster Master is the hub; **Sprite RePacker**, **RetroExport**, and **BulkBSave** handle satellite tasks it doesn't need to duplicate:

- **Sprite RePacker → Raster Master.** Pack loose frames into a sheet in Sprite RePacker, then import the sheet into Raster Master's sprite editor (or via **Sprite Sheet Import**) to bring in every frame with its crop rectangle already applied.
- **Raster Master → RetroExport.** If you need batch palette/dither options beyond what's built into Raster Master's own converter — Master Palette across a large external image set, alternate dithering, or additional image export formats like GIF/ILBM — export your sheet from Raster Master and run it through RetroExport instead of re-drawing it.
- **Raster Master (RES binary/XGF) → BulkBSave.** If you export packed binary assets rather than embedded source, run the output folder through BulkBSave to wrap each file in a BSAVE header with a DOS-safe 8.3 filename — needed if your final target is QuickBASIC or GW-BASIC on real DOS rather than FreePascal:

```basic
DIM Sprite(260)
BLOAD "SPRITE01.XGF", VARPTR(Sprite(0))
PUT (X, Y), Sprite
```

For FreePascal projects, this last step usually isn't necessary — the `TFileStream` approach above reads Raster Master's binary export directly without any DOS filename or header wrapping.
