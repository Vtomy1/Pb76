import { QbasicConverter } from "@/components/qbasic-converter"

export default function Page() {
  return (
    <main className="mx-auto min-h-screen max-w-6xl px-4 py-8 md:px-8">
      <header className="mb-8 border border-border bg-card">
        <div className="flex items-center justify-between border-b border-border bg-primary px-4 py-1.5 text-primary-foreground">
          <span className="text-xs uppercase tracking-widest">IMAGE2BAS.EXE</span>
          <span className="text-xs">SCREEN 13 · 320x200 · 256 color</span>
        </div>
        <div className="px-4 py-6">
          <h1 className="font-display text-5xl leading-none text-primary md:text-6xl">
            Image → QBASIC
          </h1>
          <p className="mt-3 max-w-2xl text-pretty text-sm text-muted-foreground">
            Upload any image and get a ready-to-run QBASIC program that redraws it in SCREEN 13 with
            a custom VGA palette — pixel-by-pixel PSET, or compact DATA statements. Everything runs
            in your browser.
          </p>
        </div>
      </header>

      <QbasicConverter />

      <footer className="mt-8 border-t border-border pt-4 text-xs text-muted-foreground">
        Paste the output into QBASIC / QB64 and run. Press any key to exit the graphics screen.
      </footer>
    </main>
  )
}
