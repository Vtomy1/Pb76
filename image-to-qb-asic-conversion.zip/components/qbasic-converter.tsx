"use client"

import type React from "react"
import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import { Button } from "@/components/ui/button"
import {
  generate,
  quantize,
  resultToImageData,
  type OutputMode,
  type QuantizeResult,
} from "@/lib/qbasic"

const MAX_W = 320
const MAX_H = 200
const PSET_LINE_WARN = 60000

function fitDimensions(origW: number, origH: number, targetW: number) {
  let w = Math.max(1, Math.min(targetW, MAX_W))
  let h = Math.round(w * (origH / origW))
  if (h > MAX_H) {
    h = MAX_H
    w = Math.round(h * (origW / origH))
  }
  return { w: Math.max(1, w), h: Math.max(1, h) }
}

function formatBytes(n: number) {
  if (n < 1024) return `${n} B`
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`
  return `${(n / (1024 * 1024)).toFixed(2)} MB`
}

export function QbasicConverter() {
  const [img, setImg] = useState<HTMLImageElement | null>(null)
  const [fileName, setFileName] = useState<string>("")
  const [origDims, setOrigDims] = useState<{ w: number; h: number } | null>(null)
  const [targetWidth, setTargetWidth] = useState(128)
  const [colors, setColors] = useState(32)
  const [mode, setMode] = useState<OutputMode>("pset")
  const [dragging, setDragging] = useState(false)
  const [copied, setCopied] = useState(false)
  const [result, setResult] = useState<QuantizeResult | null>(null)

  const workCanvas = useRef<HTMLCanvasElement | null>(null)
  const previewCanvas = useRef<HTMLCanvasElement | null>(null)

  const loadFile = useCallback((file: File) => {
    if (!file.type.startsWith("image/")) return
    setFileName(file.name.replace(/\.[^.]+$/, "") || "image")
    const reader = new FileReader()
    reader.onload = () => {
      const image = new Image()
      image.crossOrigin = "anonymous"
      image.onload = () => {
        setImg(image)
        setOrigDims({ w: image.naturalWidth, h: image.naturalHeight })
      }
      image.src = reader.result as string
    }
    reader.readAsDataURL(file)
  }, [])

  // Quantize whenever the source or sampling controls change.
  useEffect(() => {
    if (!img || !origDims) return
    const { w, h } = fitDimensions(origDims.w, origDims.h, targetWidth)
    const canvas = workCanvas.current ?? document.createElement("canvas")
    workCanvas.current = canvas
    canvas.width = w
    canvas.height = h
    const ctx = canvas.getContext("2d", { willReadFrequently: true })
    if (!ctx) return
    ctx.imageSmoothingEnabled = true
    ctx.clearRect(0, 0, w, h)
    ctx.drawImage(img, 0, 0, w, h)
    const { data } = ctx.getImageData(0, 0, w, h)
    setResult(quantize(data, w, h, colors))
  }, [img, origDims, targetWidth, colors])

  // Render the faithful QBASIC-style preview.
  useEffect(() => {
    if (!result || !previewCanvas.current) return
    const canvas = previewCanvas.current
    canvas.width = result.width
    canvas.height = result.height
    const ctx = canvas.getContext("2d")
    if (!ctx) return
    const buf = resultToImageData(result)
    ctx.putImageData(new ImageData(buf, result.width, result.height), 0, 0)
  }, [result])

  const generated = useMemo(() => (result ? generate(result, mode) : null), [result, mode])

  const pixelCount = result ? result.width * result.height : 0
  const psetTooBig = mode === "pset" && generated !== null && generated.lineCount > PSET_LINE_WARN

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault()
    setDragging(false)
    const file = e.dataTransfer.files?.[0]
    if (file) loadFile(file)
  }

  const copyCode = async () => {
    if (!generated) return
    await navigator.clipboard.writeText(generated.code)
    setCopied(true)
    setTimeout(() => setCopied(false), 1500)
  }

  const downloadCode = () => {
    if (!generated) return
    const blob = new Blob([generated.code], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${fileName || "image"}.bas`.toUpperCase()
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)]">
      {/* Left column: input + controls */}
      <section className="flex flex-col gap-4">
        <Panel title="1 · Source image">
          <label
            onDragOver={(e) => {
              e.preventDefault()
              setDragging(true)
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            className={`flex cursor-pointer flex-col items-center justify-center gap-2 border-2 border-dashed px-4 py-10 text-center transition-colors ${
              dragging ? "border-primary bg-secondary/40" : "border-border hover:border-primary/60"
            }`}
          >
            <input
              type="file"
              accept="image/*"
              className="sr-only"
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) loadFile(file)
              }}
            />
            <span className="text-sm text-foreground">
              {fileName ? `Loaded: ${fileName}` : "Drop an image here, or click to browse"}
            </span>
            <span className="text-xs text-muted-foreground">
              {origDims ? `${origDims.w} x ${origDims.h}px original` : "PNG, JPG, GIF, WebP"}
            </span>
          </label>
        </Panel>

        <Panel title="2 · Sampling">
          <div className="flex flex-col gap-5">
            <Control
              label="Target width"
              value={`${result?.width ?? targetWidth} x ${result?.height ?? "?"} px`}
            >
              <input
                type="range"
                min={16}
                max={MAX_W}
                step={1}
                value={targetWidth}
                onChange={(e) => setTargetWidth(Number(e.target.value))}
                className="w-full accent-[var(--color-primary)]"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                SCREEN 13 is {MAX_W} x {MAX_H}. Larger = more detail and more code.
              </p>
            </Control>

            <Control label="Colors" value={`${result?.palette.length ?? colors} / 256`}>
              <input
                type="range"
                min={2}
                max={256}
                step={1}
                value={colors}
                onChange={(e) => setColors(Number(e.target.value))}
                className="w-full accent-[var(--color-primary)]"
              />
              <p className="mt-1 text-xs text-muted-foreground">
                Palette is quantized with median-cut, then set via PALETTE.
              </p>
            </Control>

            <Control label="Output style">
              <div className="flex gap-2">
                <ModeButton active={mode === "pset"} onClick={() => setMode("pset")}>
                  Pixel-by-pixel PSET
                </ModeButton>
                <ModeButton active={mode === "data"} onClick={() => setMode("data")}>
                  DATA + loop
                </ModeButton>
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                {mode === "pset"
                  ? "One PSET statement per pixel — classic, but verbose."
                  : "Compact DATA statements read in a loop — best for large images."}
              </p>
            </Control>
          </div>
        </Panel>

        <Panel title="Preview">
          {result ? (
            <div className="flex flex-col items-center gap-3">
              <div className="w-full overflow-hidden border border-border bg-background p-2">
                <canvas
                  ref={previewCanvas}
                  className="mx-auto block h-auto w-full max-w-[320px]"
                  style={{ imageRendering: "pixelated", aspectRatio: `${result.width} / ${result.height}` }}
                  aria-label="QBASIC output preview"
                />
              </div>
              <p className="text-xs text-muted-foreground">
                Rendered with the exact palette QBASIC will use.
              </p>
            </div>
          ) : (
            <p className="py-8 text-center text-sm text-muted-foreground">
              Load an image to see the SCREEN 13 preview.
            </p>
          )}
        </Panel>
      </section>

      {/* Right column: output */}
      <section className="flex flex-col gap-4">
        <Panel title="3 · QBASIC output" className="flex-1">
          <div className="mb-3 flex flex-wrap items-center gap-2">
            <Button onClick={copyCode} disabled={!generated} size="sm">
              {copied ? "Copied!" : "Copy code"}
            </Button>
            <Button onClick={downloadCode} disabled={!generated} size="sm" variant="secondary">
              Download .BAS
            </Button>
            {generated && (
              <span className="ml-auto text-xs text-muted-foreground">
                {pixelCount.toLocaleString()} px · {generated.lineCount.toLocaleString()} lines ·{" "}
                {formatBytes(generated.byteSize)}
              </span>
            )}
          </div>

          {psetTooBig && (
            <p className="mb-3 border border-destructive/60 bg-destructive/15 px-3 py-2 text-xs text-foreground">
              This is {generated?.lineCount.toLocaleString()} lines. Real QBASIC caps module size —
              switch to <strong>DATA + loop</strong> or lower the target width for a file it can load.
            </p>
          )}

          {generated ? (
            <pre className="max-h-[560px] overflow-auto border border-border bg-background p-3 text-xs leading-relaxed text-accent">
              <code>{generated.code}</code>
            </pre>
          ) : (
            <div className="flex min-h-[300px] items-center justify-center text-sm text-muted-foreground">
              Your generated QBASIC program will appear here.
            </div>
          )}
        </Panel>
      </section>
    </div>
  )
}

function Panel({
  title,
  children,
  className = "",
}: {
  title: string
  children: React.ReactNode
  className?: string
}) {
  return (
    <div className={`border border-border bg-card ${className}`}>
      <div className="border-b border-border bg-secondary px-3 py-1.5">
        <h2 className="text-xs uppercase tracking-widest text-secondary-foreground">{title}</h2>
      </div>
      <div className="p-4">{children}</div>
    </div>
  )
}

function Control({
  label,
  value,
  children,
}: {
  label: string
  value?: string
  children: React.ReactNode
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between gap-2">
        <span className="text-sm text-foreground">{label}</span>
        {value && <span className="text-xs text-primary">{value}</span>}
      </div>
      {children}
    </div>
  )
}

function ModeButton({
  active,
  onClick,
  children,
}: {
  active: boolean
  onClick: () => void
  children: React.ReactNode
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`flex-1 border px-2 py-1.5 text-xs transition-colors ${
        active
          ? "border-primary bg-primary text-primary-foreground"
          : "border-border bg-background text-foreground hover:border-primary/60"
      }`}
    >
      {children}
    </button>
  )
}
