export type RGB = { r: number; g: number; b: number }

export interface QuantizeResult {
  width: number
  height: number
  palette: RGB[]
  /** palette index for each pixel, row-major (length = width * height) */
  indices: number[]
}

/**
 * Median-cut color quantization. Every pixel ends up assigned to the box it
 * settled in, so no separate nearest-color pass is needed and the mapping is
 * exact for the produced palette.
 */
export function quantize(
  data: Uint8ClampedArray,
  width: number,
  height: number,
  maxColors: number,
): QuantizeResult {
  const n = width * height
  const R = new Uint8Array(n)
  const G = new Uint8Array(n)
  const B = new Uint8Array(n)
  for (let i = 0; i < n; i++) {
    R[i] = data[i * 4]
    G[i] = data[i * 4 + 1]
    B[i] = data[i * 4 + 2]
  }

  let boxes: number[][] = [Array.from({ length: n }, (_, i) => i)]

  while (boxes.length < maxColors) {
    let target = -1
    let bestRange = -1
    let bestChannel = 0

    for (let k = 0; k < boxes.length; k++) {
      const box = boxes[k]
      if (box.length < 2) continue
      let rmin = 255,
        rmax = 0,
        gmin = 255,
        gmax = 0,
        bmin = 255,
        bmax = 0
      for (const p of box) {
        const r = R[p],
          g = G[p],
          b = B[p]
        if (r < rmin) rmin = r
        if (r > rmax) rmax = r
        if (g < gmin) gmin = g
        if (g > gmax) gmax = g
        if (b < bmin) bmin = b
        if (b > bmax) bmax = b
      }
      const rr = rmax - rmin
      const gr = gmax - gmin
      const br = bmax - bmin
      const range = Math.max(rr, gr, br)
      if (range > bestRange) {
        bestRange = range
        target = k
        bestChannel = rr >= gr && rr >= br ? 0 : gr >= br ? 1 : 2
      }
    }

    if (target < 0) break // every box has a single color

    const box = boxes[target]
    const ch = bestChannel === 0 ? R : bestChannel === 1 ? G : B
    box.sort((a, b) => ch[a] - ch[b])
    const mid = box.length >> 1
    boxes.splice(target, 1, box.slice(0, mid), box.slice(mid))
  }

  const palette: RGB[] = boxes.map((box) => {
    let r = 0,
      g = 0,
      b = 0
    for (const p of box) {
      r += R[p]
      g += G[p]
      b += B[p]
    }
    const l = box.length || 1
    return { r: Math.round(r / l), g: Math.round(g / l), b: Math.round(b / l) }
  })

  const indices = new Array<number>(n)
  for (let k = 0; k < boxes.length; k++) {
    for (const p of boxes[k]) indices[p] = k
  }

  return { width, height, palette, indices }
}

/** Convert an 8-bit RGB color to the packed value QBASIC's PALETTE expects (6-bit channels). */
export function paletteValue(c: RGB): number {
  return (c.r >> 2) + (c.g >> 2) * 256 + (c.b >> 2) * 65536
}

/** Build an RGBA buffer from a quantized result, for rendering a faithful preview. */
export function resultToImageData(result: QuantizeResult): Uint8ClampedArray {
  const { width, height, palette, indices } = result
  const out = new Uint8ClampedArray(width * height * 4)
  for (let i = 0; i < width * height; i++) {
    const c = palette[indices[i]]
    out[i * 4] = c.r
    out[i * 4 + 1] = c.g
    out[i * 4 + 2] = c.b
    out[i * 4 + 3] = 255
  }
  return out
}

export type OutputMode = "pset" | "data"

export interface GeneratedCode {
  code: string
  lineCount: number
  byteSize: number
}

function paletteSetupLines(palette: RGB[]): string[] {
  const lines: string[] = ["' --- Palette (256-color VGA, 6-bit channels) ---"]
  palette.forEach((c, i) => {
    lines.push(`PALETTE ${i}, ${paletteValue(c)}`)
  })
  return lines
}

const FOOTER = ["", "' --- Wait for a key, then restore text mode ---", "DO: LOOP WHILE INKEY$ = \"\"", "SCREEN 0", "WIDTH 80", "END"]

/** Literal pixel-by-pixel PSET output (the classic approach). */
export function generatePset(result: QuantizeResult): GeneratedCode {
  const { width, height, palette, indices } = result
  const lines: string[] = []
  lines.push(`' QBASIC image - ${width} x ${height}, ${palette.length} colors`)
  lines.push("' Generated with the image-to-QBASIC converter")
  lines.push("SCREEN 13")
  lines.push(...paletteSetupLines(palette))
  lines.push("")
  lines.push(`' --- Draw ${width} x ${height} pixels ---`)
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      lines.push(`PSET (${x}, ${y}), ${indices[y * width + x]}`)
    }
  }
  lines.push(...FOOTER)
  const code = lines.join("\n")
  return { code, lineCount: lines.length, byteSize: code.length }
}

function chunkedData(values: number[], perLine: number): string[] {
  const out: string[] = []
  for (let i = 0; i < values.length; i += perLine) {
    out.push("DATA " + values.slice(i, i + perLine).join(", "))
  }
  return out
}

/** Compact DATA + READ/PSET loop output (stays within QBASIC's module size limits). */
export function generateData(result: QuantizeResult): GeneratedCode {
  const { width, height, palette, indices } = result
  const lines: string[] = []
  lines.push(`' QBASIC image - ${width} x ${height}, ${palette.length} colors`)
  lines.push("' Generated with the image-to-QBASIC converter")
  lines.push("SCREEN 13")
  lines.push("DIM x AS INTEGER, y AS INTEGER, c AS INTEGER, i AS INTEGER, p AS LONG")
  lines.push("")
  lines.push(`' --- Load palette (${palette.length} colors) ---`)
  lines.push(`FOR i = 0 TO ${palette.length - 1}`)
  lines.push("  READ p")
  lines.push("  PALETTE i, p")
  lines.push("NEXT i")
  lines.push("")
  lines.push(`' --- Read and draw ${width} x ${height} pixels ---`)
  lines.push(`FOR y = 0 TO ${height - 1}`)
  lines.push(`  FOR x = 0 TO ${width - 1}`)
  lines.push("    READ c")
  lines.push("    PSET (x, y), c")
  lines.push("  NEXT x")
  lines.push("NEXT y")
  lines.push(...FOOTER)
  lines.push("")
  lines.push("' --- Palette data ---")
  lines.push(...chunkedData(palette.map(paletteValue), 12))
  lines.push("")
  lines.push("' --- Pixel data ---")
  lines.push(...chunkedData(indices, 20))
  const code = lines.join("\n")
  return { code, lineCount: lines.length, byteSize: code.length }
}

export function generate(result: QuantizeResult, mode: OutputMode): GeneratedCode {
  return mode === "pset" ? generatePset(result) : generateData(result)
}
